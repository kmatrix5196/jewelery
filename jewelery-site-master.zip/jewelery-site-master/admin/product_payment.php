<!doctype html>
<html class="no-js" lang="en">

<head>
  <meta charset="utf-8">
  <meta http-equiv="x-ua-compatible" content="ie=edge">
  <title>Jewelery Site Dashboard</title>
  <meta name="robots" content="noindex, follow" />
  <meta name="description" content="">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- Favicon -->
    <link rel="shortcut icon" type="image/x-icon" href="assets/img/favicon.ico">

    <!-- CSS
	============================================ -->

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="assets/css/vendor/bootstrap.min.css">

    <!-- Icon Font CSS -->
    <link rel="stylesheet" href="assets/css/vendor/material-design-iconic-font.min.css">
    <link rel="stylesheet" href="assets/css/vendor/font-awesome.min.css">
    <link rel="stylesheet" href="assets/css/vendor/themify-icons.css">
    <link rel="stylesheet" href="assets/css/vendor/cryptocurrency-icons.css">

    <!-- Plugins CSS -->
    <link rel="stylesheet" href="assets/css/plugins/plugins.css">

    <!-- Helper CSS -->
    <link rel="stylesheet" href="assets/css/helper.css">

    <!-- Main Style CSS -->
    <link rel="stylesheet" href="assets/css/style.css">

    <!-- Custom Style CSS Only For Demo Purpose -->
    <link id="cus-style" rel="stylesheet" href="assets/css/style-primary.css">
    <link rel="stylesheet" href="assets/css/preloader.css">
</head>

<body>
    <?php include'php/preloader.php'?>
    <div class="main-wrapper">


    <?php include'php/header.php'?>

        <!-- Content Body Start -->
        <div class="content-body">

            <!-- Page Headings Start -->
            <div class="row justify-content-between align-items-center mb-10">

                <!-- Page Heading Start -->
                <div class="col-12 col-lg-auto mb-20">
                    <div class="page-heading">
                        <h3>Product Payment</span></h3>
                    </div>
                </div><!-- Page Heading End -->

            </div><!-- Page Headings End -->

            <div class="row">

                <!--Form Wizard Horizontal Start-->
                <div class="col-12 mb-30">
                    <div class="box">
                        <div class="box-head">

                        </div>
                        <div class="box-body">

                            <div class="smart-wizard">
                                <ul>
                                    <li><a href="#step-1">1. Step One</a></li>
                                    <li><a href="#step-2">2. Step Two</a></li>
                                    <li><a href="#step-3">3. Step Three</a></li>
                                    <li><a href="#step-4">4. Step Four</a></li>
                                </ul>

                                <div>
                                    <div id="step-1">
                                        <form action="#">
                                            <div class="row mbn-20">
                                                <div class="col-12 mb-20">
                                                    <h4>Step 1 Form</h4>
                                                </div>
                                                <div class="col-lg-6 col-12 mb-20"><input type="text" placeholder="Your Name" class="form-control"></div>
                                                <div class="col-lg-6 col-12 mb-20"><input type="email" placeholder="Your Email" class="form-control"></div>
                                                <div class="col-12 mb-20"><textarea class="form-control" placeholder="Message"></textarea></div>
                                                <div class="col-lg-6 col-12 mb-20"><input type="submit" class="button button-primary" value="Submit"></div>
                                            </div>
                                        </form>
                                    </div>
                                    <div id="step-2">
                                        <form action="#">
                                            <div class="row mbn-20">
                                                <div class="col-12 mb-20">
                                                    <h4>Step 2 Form</h4>
                                                </div>
                                                <div class="col-lg-6 col-12 mb-20"><input type="text" placeholder="Your Name" class="form-control"></div>
                                                <div class="col-lg-6 col-12 mb-20"><input type="email" placeholder="Your Email" class="form-control"></div>
                                                <div class="col-12 mb-20"><textarea class="form-control" placeholder="Message"></textarea></div>
                                                <div class="col-lg-6 col-12 mb-20"><input type="submit" class="button button-primary" value="Submit"></div>
                                            </div>
                                        </form>
                                    </div>
                                    <div id="step-3">
                                        <form action="#">
                                            <div class="row mbn-20">
                                                <div class="col-12 mb-20">
                                                    <h4>Step 3 Form</h4>
                                                </div>
                                                <div class="col-lg-6 col-12 mb-20"><input type="text" placeholder="Your Name" class="form-control"></div>
                                                <div class="col-lg-6 col-12 mb-20"><input type="email" placeholder="Your Email" class="form-control"></div>
                                                <div class="col-12 mb-20"><textarea class="form-control" placeholder="Message"></textarea></div>
                                                <div class="col-lg-6 col-12 mb-20"><input type="submit" class="button button-primary" value="Submit"></div>
                                            </div>
                                        </form>
                                    </div>
                                    <div id="step-4">
                                        <form action="#">
                                            <div class="row mbn-20">
                                                <div class="col-12 mb-20">
                                                    <h4>Step 4 Form</h4>
                                                </div>
                                                <div class="col-lg-6 col-12 mb-20"><input type="text" placeholder="Your Name" class="form-control"></div>
                                                <div class="col-lg-6 col-12 mb-20"><input type="email" placeholder="Your Email" class="form-control"></div>
                                                <div class="col-12 mb-20"><textarea class="form-control" placeholder="Message"></textarea></div>
                                                <div class="col-lg-6 col-12 mb-20"><input type="submit" class="button button-primary" value="Submit"></div>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
                <!--Form Wizard Horizontal End-->




            </div>

        </div><!-- Content Body End -->

      <?php include'php/footer.php'?>

    </div>

    <!-- JS
============================================ -->

    <!-- Global Vendor, plugins & Activation JS -->
    <script src="assets/js/vendor/modernizr-3.6.0.min.js"></script>
    <script src="assets/js/vendor/jquery-3.3.1.min.js"></script>
    <script src="assets/js/vendor/popper.min.js"></script>
    <script src="assets/js/vendor/bootstrap.min.js"></script>
    <!--Plugins JS-->
    <script src="assets/js/plugins/perfect-scrollbar.min.js"></script>
    <script src="assets/js/plugins/tippy4.min.js.js"></script>
    <!--Main JS-->
    <script src="assets/js/main.js"></script>

    <!-- Plugins & Activation JS For Only This Page -->
    <script src="assets/js/plugins/smartWizard/jquery.smartWizard.min.js"></script>
    <script src="assets/js/plugins/smartWizard/smartWizard.active.js"></script>
    <script src="assets/js/preloader.js"></script>
</body>

</html>
<!-- Localized -->
