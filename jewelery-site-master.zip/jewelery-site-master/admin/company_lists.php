<!doctype html>
<html class="no-js" lang="en">

<head>
  <meta charset="utf-8">
  <meta http-equiv="x-ua-compatible" content="ie=edge">
  <title>Jewelery Site Dashboard</title>
  <meta name="robots" content="noindex, follow" />
  <meta name="description" content="">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- Favicon -->
    <link rel="shortcut icon" type="image/x-icon" href="assets/img/favicon.ico">

    <!-- CSS
	============================================ -->

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="assets/css/vendor/bootstrap.min.css">

    <!-- Icon Font CSS -->
    <link rel="stylesheet" href="assets/css/vendor/material-design-iconic-font.min.css">
    <link rel="stylesheet" href="assets/css/vendor/font-awesome.min.css">
    <link rel="stylesheet" href="assets/css/vendor/themify-icons.css">
    <link rel="stylesheet" href="assets/css/vendor/cryptocurrency-icons.css">

    <!-- Plugins CSS -->
    <link rel="stylesheet" href="assets/css/plugins/plugins.css">

    <!-- Helper CSS -->
    <link rel="stylesheet" href="assets/css/helper.css">

    <!-- Main Style CSS -->
    <link rel="stylesheet" href="assets/css/style.css">

    <!-- Custom Style CSS Only For Demo Purpose -->
    <link id="cus-style" rel="stylesheet" href="assets/css/style-primary.css">
    <link rel="stylesheet" href="assets/css/preloader.css">
</head>

<body>
    <?php include'php/preloader.php'?>
    <div class="main-wrapper">


        <?php include'php/header.php'?>
        <!-- Content Body Start -->
        <div class="content-body">

            <!-- Page Headings Start -->
            <div class="row justify-content-between align-items-center mb-10">

                <!-- Page Heading Start -->
                <div class="col-12 col-lg-auto mb-20">
                    <div class="page-heading">
                        <h3>Jewelery Site <span>/ Company Lists</span></h3>
                    </div>
                </div><!-- Page Heading End -->

            </div><!-- Page Headings End -->

            <div class="row mt-40">
                <!--Order Details Customer Information Start-->
                <div class="col-12 mb-30">
                    <div class="order-details-customer-info row mbn-20">

                        <!--Billing Info Start-->
                        <div class="col-lg-5 col-md-6 col-12 mb-20">
                            <h4 class="mb-25">Company Profile</h4>
                            <img src="https://images.unsplash.com/photo-1497366754035-f200968a6e72?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1050&q=80" alt="">
                        </div>
                        <!--Billing Info End-->
                        <div class="col-lg-1">

                        </div>
                        <!--Shipping Info Start-->
                        <div class="col-lg-6 col-md-6 col-12 mb-20">
                            <h4 class="mb-25">Company Info</h4>
                            <ul>
                                <li> <span>Company Name</span> <span>Yiwa Yisa Company Ltd;</span> </li>
                                <li> <span>Business Type</span> <span>Trading Company</span> </li>
                                <li> <span>Main Products</span> <span>13/2 Minar St, Sanfrancisco <br>CA 8788 USA.</span> </li>
                                <li> <span>Total Employee</span> <span>11-50 people</span> </li>
                                <li> <span>Location</span> <span>Yangon <br>,Myanmar</span> </li>
                                <li> <span>Year Estsblished</span> <span> 2011</span> </li>
                            </ul>
                        </div>
                        <!--Shipping Info End-->
                    </div>
                </div>
                <!--Order Details Customer Information Start-->
              </div><hr>

                <div class="row mt-40">
                    <!--Order Details Customer Information Start-->
                    <div class="col-12 mb-30">
                        <div class="order-details-customer-info row mbn-20">

                            <!--Billing Info Start-->
                            <div class="col-lg-5 col-md-6 col-12 mb-20">
                                <h4 class="mb-25">Company Profile</h4>
                                <img src="https://images.unsplash.com/photo-1497366754035-f200968a6e72?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1050&q=80" alt="">
                            </div>
                            <!--Billing Info End-->
                            <div class="col-lg-1">

                            </div>
                            <!--Shipping Info Start-->
                            <div class="col-lg-6 col-md-6 col-12 mb-20">
                                <h4 class="mb-25">Company Info</h4>
                                <ul>
                                    <li> <span>Company Name</span> <span>Yiwa Yisa Company Ltd;</span> </li>
                                    <li> <span>Business Type</span> <span>Trading Company</span> </li>
                                    <li> <span>Main Products</span> <span>13/2 Minar St, Sanfrancisco <br>CA 8788 USA.</span> </li>
                                    <li> <span>Total Employee</span> <span>11-50 people</span> </li>
                                    <li> <span>Location</span> <span>Yangon <br>,Myanmar</span> </li>
                                    <li> <span>Year Estsblished</span> <span> 2011</span> </li>
                                </ul>
                            </div>
                            <!--Shipping Info End-->
                        </div>
                    </div>
                  </div><hr>
                    <!--Order Details Customer Information Start-->

                    <div class="row mt-40">
                        <!--Order Details Customer Information Start-->
                        <div class="col-12 mb-30">
                            <div class="order-details-customer-info row mbn-20">

                                <!--Billing Info Start-->
                                <div class="col-lg-5 col-md-6 col-12 mb-20">
                                    <h4 class="mb-25">Company Profile</h4>
                                    <img src="https://images.unsplash.com/photo-1497366754035-f200968a6e72?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1050&q=80" alt="">
                                </div>
                                <!--Billing Info End-->
                                <div class="col-lg-1">

                                </div>
                                <!--Shipping Info Start-->
                                <div class="col-lg-6 col-md-6 col-12 mb-20">
                                    <h4 class="mb-25">Company Info</h4>
                                    <ul>
                                        <li> <span>Company Name</span> <span>Yiwa Yisa Company Ltd;</span> </li>
                                        <li> <span>Business Type</span> <span>Trading Company</span> </li>
                                        <li> <span>Main Products</span> <span>13/2 Minar St, Sanfrancisco <br>CA 8788 USA.</span> </li>
                                        <li> <span>Total Employee</span> <span>11-50 people</span> </li>
                                        <li> <span>Location</span> <span>Yangon <br>,Myanmar</span> </li>
                                        <li> <span>Year Estsblished</span> <span> 2011</span> </li>
                                    </ul>
                                </div>
                                <!--Shipping Info End-->
                            </div>
                        </div>
                        <!--Order Details Customer Information Start-->
                      </div><hr>


            </div>

        </div><!-- Content Body End -->

        <?php include'php/footer.php'?>

    </div>

    <!-- JS
============================================ -->

    <!-- Global Vendor, plugins & Activation JS -->
    <script src="assets/js/vendor/modernizr-3.6.0.min.js"></script>
    <script src="assets/js/vendor/jquery-3.3.1.min.js"></script>
    <script src="assets/js/vendor/popper.min.js"></script>
    <script src="assets/js/vendor/bootstrap.min.js"></script>
    <!--Plugins JS-->
    <script src="assets/js/plugins/perfect-scrollbar.min.js"></script>
    <script src="assets/js/plugins/tippy4.min.js.js"></script>
    <!--Main JS-->
    <script src="assets/js/main.js"></script>
    <script src="assets/js/preloader.js"></script>
</body>

</html>
<!-- Localized -->
