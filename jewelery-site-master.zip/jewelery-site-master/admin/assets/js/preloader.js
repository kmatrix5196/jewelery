$(window).on("load",function(){
    
    $(".loading").fadeOut("slow");
});