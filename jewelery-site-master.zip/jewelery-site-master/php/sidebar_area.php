<aside class="sidebar-wrapper">
    <!-- single sidebar start -->
    <div class="sidebar-single">
        <h5 class="sidebar-title">By Collections</h5>
        <div class="sidebar-body">
            <ul class="shop-categories">
              <li><a href="#">Necklaces </a></li>
              <li><a href="#">Pendants </a></li>
              <li><a href="#">Barcelets </a></li>
              <li><a href="#">Earrings </a></li>
              <li><a href="#">Rings </a></li>
              <li><a href="#">Charms </a></li>
              <li><a href="#">Brooches </a></li>
            </ul>
        </div>
    </div>
    <!-- single sidebar end -->



    <!-- single sidebar start -->
    <div class="sidebar-single">
        <h5 class="sidebar-title">By Jewelery</h5>
        <div class="sidebar-body">
            <ul class="shop-categories">
              <li><a href="#">Diamonds </a></li>
              <li><a href="#">Ruby </a></li>
              <li><a href="#">Pearl </a></li>
              <li><a href="#">Jade </a></li>
              <li><a href="#">Sapphires </a></li>
              <li><a href="#">Loose Stone </a></li>

            </ul>
        </div>
    </div>
    <!-- single sidebar end -->

    <!-- single sidebar start -->
    <div class="sidebar-single">
        <h5 class="sidebar-title">By Date</h5>
        <div class="sidebar-body">
            <ul class="shop-categories">
              <li><a href="#"> ( 2.8.2019 ) </a></li>
              <li><a href="#"> ( 4.8.2019 ) </a></li>
              <li><a href="#"> ( 9.8.2019 ) </a></li>


            </ul>
        </div>
    </div>
    <!-- single sidebar end -->


  
</aside>
