<footer class="footer-widget-area Royal_Crescent_Light">
    <div class="footer-top section-padding">
        <div class="container">
            <div class="row">
                <div class="col-lg-3 col-md-6">
                    <div class="widget-item">

                    </div>
                </div>
                <div class="col-lg-3 col-md-6">
                    <div class="widget-item ">
                        <h6 class="widget-title Royal_Crescent_Bold">Contact Us</h6>
                        <div class="widget-body Royal_Crescent_Light">
                            <address class="contact-block">
                                <ul>
                                    <li><i class="pe-7s-home"></i> <a href="contact-us.php">Contact Us</a></li>
                                    <li><i class="pe-7s-mail"></i> <a href="mailto:demo@plazathemes.com"> Call Now : 222222 </a></li>
                                    <li><i class="pe-7s-call"></i> <a href="tel:(012)800456789987">Make an Appointment</a></li>
                                </ul>
                            </address>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6">
                    <div class="widget-item">
                        <h6 class="widget-title Royal_Crescent_Bold">Information</h6>
                        <div class="widget-body Royal_Crescent_Light">
                            <ul class="info-list">
                                <li><a href="#">Sustainability</a></li><br>
                                <li><a href="#">CA Supply Chains Act</a></li><br>
                                <li><a href="#">Investors</a></li>
                            </ul>
                        </div>
                    </div>
                </div>

                <div class="col-lg-3 col-md-6">
                    <div class="widget-item">
                        <h6 class="widget-title Royal_Crescent_Bold">Information</h6>
                        <div class="widget-body Royal_Crescent_Light">
                            <ul class="info-list">
                                <li><a href="#">Wedding & Gift Registry</a></li><br>
                                <li><a href="#">Business Accounts</a></li><br>
                                <li><a href="#">Tiffany for the Press</a></li>
                            </ul>
                        </div>
                    </div>
                </div>

            </div>
            <div class="row align-items-center mt-20">
              <!--  <div class="col-md-6">
                         <div class="newsletter-wrapper">
                            <h6 class="widget-title-text">Contact Us</h6>
                            <form class="newsletter-inner" id="mc-form">
                                <input type="email" class="news-field" id="mc-email" autocomplete="off" placeholder="Enter your email address">
                                <button class="news-btn" id="mc-submit">Subscribe</button>
                            </form>
                        <! mailchimp-alerts Start -->
                        <div class="mailchimp-alerts">
                            <div class="mailchimp-submitting"></div><!-- mailchimp-submitting end -->
                            <div class="mailchimp-success"></div><!-- mailchimp-success end -->
                            <div class="mailchimp-error"></div><!-- mailchimp-error end -->
                        </div>
                        <!-- mailchimp-alerts end -->
                   
                    <!-- </div> -->
               
            </div>
        </div>
    </div>
    <div class="footer-bottom">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="copyright-text text-center">
                        <p>Design By <a href="#">HEX Creative</a>© 2019</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</footer>
